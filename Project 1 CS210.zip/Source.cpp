/*
File: Project 1 CS 210
Author: Laura Ward Jumel
Class: CS210
Due Date: 11/12/23
*/

#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

// Clock class definition
class Clock {
private:
    int hours;
    int minutes;
    int seconds;

public:
    // Constructor to initialize the clock with a specific time
    Clock(int h, int m, int s) : hours(h), minutes(m), seconds(s) {}

    // Function to add an hour to the clock
    void addHour() {
        hours = (hours + 1) % 24;
    }

    // Function to add a minute to the clock
    void addMinute() {
        minutes = (minutes + 1) % 60;
    }

    // Function to add a second to the clock
    void addSecond() {
        seconds = (seconds + 1) % 60;
    }

    // Function to display the time in 12-hour format
    void display12Hour() {
        cout << "********************\n";
        cout << "*  12 hour clock   *\n";
        cout << "*      " << setw(2) << setfill('0') << (hours % 12 == 0 ? 12 : hours % 12)
            << ":" << setw(2) << setfill('0') << minutes << ":" << setw(2) << setfill('0') << seconds
            << (hours < 12 ? " AM" : " PM") << "      *\n";
        cout << "********************\n";
    }

    // Function to display the time in 24-hour format
    void display24Hour() {
        cout << "********************\n";
        cout << "*   24 hour clock    *\n";
        cout << "*            " << setw(2) << setfill('0') << hours << ":"
            << setw(2) << setfill('0') << minutes << " " << ":" << setw(2) << setfill('0') << seconds + "* \n";
        cout << "********************\n";
    }
};

// Function to display the menu and get user input
char displayMenu() {
    cout << "1. Add an hour\n";
    cout << "2. Add a minute\n";
    cout << "3. Add a second\n";
    cout << "4. Exit\n";
    cout << "Enter your choice: ";

    char choice;
    cin >> choice;
    return choice;
}

int main() {
    int initialHours, initialMinutes, initialSeconds;

    cout << "Enter initial time (hours minutes seconds): ";
    cin >> initialHours >> initialMinutes >> initialSeconds;

    // Create an instance of the Clock class
    Clock myClock(initialHours, initialMinutes, initialSeconds);

    char userChoice;

    do {
        // Display both 12- and 24-hour clocks
        myClock.display12Hour();
        myClock.display24Hour();

        // Display menu and get user input
        userChoice = displayMenu();

        // Process user input
        switch (userChoice) {
        case '1':
            myClock.addHour();
            break;
        case '2':
            myClock.addMinute();
            break;
        case '3':
            myClock.addSecond();
            break;
        case '4':
            cout << "Exiting program. Goodbye!\n";
            break;
        default:
            cout << "Invalid choice. Please try again.\n";
        }

    } while (userChoice != '4');

    return 0;
}
